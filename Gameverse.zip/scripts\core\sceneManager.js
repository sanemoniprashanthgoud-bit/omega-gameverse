﻿// Scene management logic\n
