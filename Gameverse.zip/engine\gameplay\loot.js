﻿// Module: loot.js

