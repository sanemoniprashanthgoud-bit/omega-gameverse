﻿// Input handling utilities\n
