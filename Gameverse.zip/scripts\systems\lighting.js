﻿// System: lighting.js

