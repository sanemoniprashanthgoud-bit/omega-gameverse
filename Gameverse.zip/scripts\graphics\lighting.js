﻿// Lighting utilities\n
