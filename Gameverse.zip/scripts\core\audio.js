﻿// Core audio helpers\n
