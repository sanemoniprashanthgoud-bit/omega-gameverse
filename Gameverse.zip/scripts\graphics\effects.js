﻿// Graphics effects\n
