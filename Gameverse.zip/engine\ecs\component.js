﻿// Module: component.js

