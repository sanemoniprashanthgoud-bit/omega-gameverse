﻿// Entity: npc.js

