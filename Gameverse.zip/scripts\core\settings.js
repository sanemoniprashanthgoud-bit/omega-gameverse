﻿// Settings management\n
