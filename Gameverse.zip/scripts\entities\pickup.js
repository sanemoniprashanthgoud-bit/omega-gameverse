﻿// Entity: pickup.js

